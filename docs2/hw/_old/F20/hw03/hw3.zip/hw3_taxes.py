# ----------------------------------------------------------
# --------             HW 3: Part 1                ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after you have completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this part:
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------

# Write your python program below:
# ----------------------------------------------------------
# --------             HW 3: Part 3              ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after you have completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this part:
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------

# Modify the program below, as specified in the homework description

username = input("What do they call you, worthy adventurer? ")
print("\nWelcome, " + username + ''', to the labyrinth, where you may seek
unparalleled treasure. Once you cross the threshold, the door slams
shut behind you, leaving you in darkness except for the dim light of your 
torch. The passageway immediately splits in two directions.\n''')

direction = input("Do you turn left or right? [left/right] ")
if direction == "left":
	print("\nYou walk carefully down the left passageway and begin your adventure.\n")
else:
	print("\nYou sprint down the right passageway eager to start your adventure.\n")
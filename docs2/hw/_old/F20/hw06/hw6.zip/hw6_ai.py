# ----------------------------------------------------------
# --------               hw6 ai                    ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:  
# Hours spent on this program: 
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------


def no_ai(paddle_center_y, paddle_size_y, ball_center_y, opponent_center_y, board_size_y):
    return None # Do not change


def beginner_pong_ai(paddle_center_y, paddle_size_y, ball_center_y, opponent_center_y, board_size_y):
    """Doctests here"""
    return None # Change with your solution


def intermediate_pong_ai(paddle_center_y, paddle_size_y, ball_center_y, opponent_center_y, board_size_y):
    """Doctests here"""
    return None # Change with your solution


def expert_pong_ai(ai_center_y, paddle_size_y, ball_center_y, opponent_center_y, board_size_y):
    """Complete this function for the challenge problem"""
    return None # Change with your (optional) solution


if __name__ == "__main__":
    import doctest
    doctest.testmod()

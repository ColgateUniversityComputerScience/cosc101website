import sys
import os
import re
import importlib
import contextlib
import unittest
import difflib
import builtins
from io import StringIO


def run_function(filename, func_name, inputs=[]):
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload
    module = importlib.import_module(module_name)
    func = getattr(module, func_name)
    retval = func(*inputs)
    return retval


def count_doctests(filename, func_name):
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload
    module = importlib.import_module(module_name)
    func = getattr(module, func_name)
    docstr = func.__doc__
    if not docstr:
      return 0
    else:
      return docstr.count(">>>")


class TestGeometry(unittest.TestCase):
  FILENAME = 'hw6_geometry.py'

  def testCheckWallCollisionDoctests(self):
    num_tests = count_doctests(TestGeometry.FILENAME, "check_wall_collision")
    self.assertTrue(num_tests >= 5, "Only {} doctests".format(num_tests))

  def testCheckWallCollisionBottom(self):
    res = run_function(TestGeometry.FILENAME, "check_wall_collision", [400, 595, 5, 900, 600])
    self.assertEqual(res, 'bottom')

  def testCheckWallCollisionNone(self):
    res = run_function(TestGeometry.FILENAME, "check_wall_collision", [400, 400, 10, 900, 600])
    self.assertEqual(res, None)


  def testCheckPaddleCollisionDoctests(self):
    num_tests = count_doctests(TestGeometry.FILENAME, "check_paddle_collision")
    self.assertTrue(num_tests >= 5, "Only {} doctests".format(num_tests))

  def testCheckPaddleCollision0(self):
    res = run_function(TestGeometry.FILENAME, "check_paddle_collision", [20, 400, 10, 5, 400, 10, 100])
    self.assertEqual(res, 0.0)

  def testCheckPaddleCollisionHalf(self):
    res = run_function(TestGeometry.FILENAME, "check_paddle_collision", [20, 425, 10, 5, 400, 10, 100])
    self.assertEqual(res, 0.5) 


class TestAI(unittest.TestCase):
  FILENAME = 'hw6_ai.py'

  def testBeginnerPongAIDoctests(self):
    num_tests = count_doctests(TestAI.FILENAME, "beginner_pong_ai")
    self.assertTrue(num_tests >= 3, "Only {} doctests".format(num_tests))

  def testBeginnerPongAIUp(self):
    res = run_function(TestAI.FILENAME, "beginner_pong_ai", [400, 10, 79, 0, 0])
    self.assertEqual(res, 'up')



  def testIntermediatePongAIDoctests(self):
    num_tests = count_doctests(TestAI.FILENAME, "intermediate_pong_ai")
    self.assertTrue(num_tests >= 3, "Only {} doctests".format(num_tests))

  def testIntermediatePongAIUp(self):
    res = run_function(TestAI.FILENAME, "intermediate_pong_ai", [400, 10, 397, 100, 600])
    self.assertEqual(res, 'up')


if __name__ == '__main__':
    unittest.main(verbosity=10)

# ----------------------------------------------------------
# --------               hw6 geometry              ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:  
# Hours spent on this program: 
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------

# Your code here


if __name__ == "__main__":
    import doctest
    doctest.testmod()

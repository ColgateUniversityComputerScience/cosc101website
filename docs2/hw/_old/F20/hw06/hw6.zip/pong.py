# ----------------------------------------------------------
# --------               hw6 pong                  ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:  
# Hours spent on this program: 
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------

from graphics import *
import random
import math
import time

from hw6_geometry import check_wall_collision, check_paddle_collision
from hw6_ai import no_ai, beginner_pong_ai, intermediate_pong_ai, expert_pong_ai

AI_player = no_ai

# constants
paddle_size_x = 20
paddle_size_y = 140
board_size_x = 800
board_size_y = 600
ball_radius = 12
ball_speed = 10
user_speed = 15
ai_speed = 15


def create_paddle(center_x, center_y, height, width, color, win):
    """Create and draw a rectangular paddle"""
    p1 = Point(center_x - width/2, center_y - height/2)
    p2 = Point(center_x + width/2, center_y + height/2)
    paddle = Rectangle(p1, p2)
    paddle.setFill(color)
    paddle.draw(win)
    return paddle


def create_ball(center_x, center_y, radius, color, win):
    """Create and draw a circular ball"""
    center = Point(center_x, center_y)
    ball = Circle(center, radius)
    ball.setFill(color)
    ball.draw(win)
    return ball


def create_window(width, height):
    """Create a game board window using the graphics library"""
    win = GraphWin("GameBoard", width, height, autoflush=False)
    return win


def draw_scores(score1, score2, win):
    """Draws the current scores on the stadium window"""
    s1 = Text(Point(int(board_size_x/4), 20), str(score1))
    s2 = Text(Point(int(board_size_x*3/4), 30), str(score2))
    s1.setSize(30)
    s2.setSize(30)
    s1.draw(win)
    s2.draw(win)
    return s1, s2

def main():
    win = create_window(board_size_x, board_size_y)
    user = create_paddle(board_size_x - 10, board_size_y/2, paddle_size_y, paddle_size_x, "Green", win)
    ai = create_paddle(10, board_size_y/2, paddle_size_y, paddle_size_x, "Blue", win)
    ball = create_ball(board_size_x/2, board_size_y/2, ball_radius, "Orange", win)
 
    ball_vx = ball_speed * 0.75
    ball_vy = 0

    user_score = 0
    ai_score = 0
    ai_score_display, user_score_display= draw_scores(ai_score, user_score, win)

    while user_score < 5 and ai_score < 5:
        # Get positions of objects
        user_center_y = user.getCenter().getY()
        user_center_x = user.getCenter().getX()
        ai_center_y = ai.getCenter().getY()
        ai_center_x = ai.getCenter().getX()
        ball_center_x = ball.getCenter().getX()
        ball_center_y = ball.getCenter().getY()

        # Check collisions
        wall_collision = check_wall_collision(
            ball_center_x, ball_center_y, ball_radius, board_size_x, board_size_y)
        user_collision = check_paddle_collision(
            ball_center_x, ball_center_y, ball_radius, user_center_x, user_center_y, paddle_size_x, paddle_size_y)
        ai_collision = check_paddle_collision(
            ball_center_x, ball_center_y, ball_radius, ai_center_x, ai_center_y, paddle_size_x, paddle_size_y)

        # If a player scored, reset the game and update the score
        if wall_collision == "left" or wall_collision == "right":
            ball.undraw()
            ball = create_ball(board_size_x/2, board_size_y/2, ball_radius, "Orange", win)
            ball_vx = ball_speed * 0.75
            ball_vy = 0
            user.move(0, board_size_y/2 - user_center_y)
            ai.move(0, board_size_y/2 - ai_center_y)
            time.sleep(1)
            if wall_collision == "left":
                user_score += 1
                user_score_display.setText(str(user_score))
            else:
                ai_score += 1
                ai_score_display.setText(str(ai_score))

        # If the ball hit a wall, invert its y velocity
        elif wall_collision == "top" or wall_collision == "bottom":
            ball_vy = -ball_vy

        # If the ball hit a paddle, change its velocity depending on where on the paddle it hit
        elif user_collision is not None:
            if user_collision > 0.75:
                user_collision = 0.75
            elif user_collision < -0.75:
                user_collision = -0.75
            ball_v = abs(user_collision) * ball_speed + ball_speed
            ball_angle = user_collision * 0.9 * (math.pi/2)
            ball_vx = -ball_v * math.cos(ball_angle)
            ball_vy = ball_v * math.sin(ball_angle)

        elif ai_collision is not None:
            if ai_collision > 0.75:
                ai_collision = 0.75
            elif ai_collision < -0.75:
                ai_collision = -0.75
            ball_v = abs(ai_collision) * ball_speed + ball_speed
            ball_angle = ai_collision * 0.8 * (math.pi/2)
            ball_vx = ball_v * math.cos(ball_angle) + random.random()
            ball_vy = ball_v * math.sin(ball_angle) + random.random()
            
        # check key press to move user or exit
        key = win.checkKey()
        if key == "Down":
            if user_center_y + user_speed <= board_size_y:
                user.move(0, user_speed)
        elif key == "Up":
            if user_center_y - user_speed >= 0:
                user.move(0, -user_speed)
        elif key == "Escape":
            win.close()
            break

        # move AI
        move_ai = AI_player(ai_center_y, paddle_size_y, ball_center_y, user_center_y, board_size_y)
        if move_ai == "up":
            ai.move(0, -ai_speed)
        elif move_ai == "down":
            ai.move(0, ai_speed)

        #move ball
        ball.move(ball_vx, ball_vy)

        #update window
        win.update()


if __name__ == "__main__":
    main()
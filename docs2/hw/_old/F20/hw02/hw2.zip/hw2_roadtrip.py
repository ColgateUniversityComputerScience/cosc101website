# ----------------------------------------------------------
# --------               hw2 road trip             ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:  
# Hours spent on this problem: 
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------

# write your python program for the road trip here


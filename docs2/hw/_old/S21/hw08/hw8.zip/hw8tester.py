import sys
import os
import re
import importlib
import contextlib
import unittest
import difflib
import webbrowser
import builtins
import inspect
import traceback
from io import StringIO


class mocked_input(contextlib.ContextDecorator):
    def __init__(self, inputs=[], write_prompt=True, write_input=True):
        self._inputs = iter(inputs)
        self._write_prompt = write_prompt
        self._write_input = write_input
        self._realinput = builtins.input

    def _fake_input(self, prompt=''):
        try:
            _input = str(next(self._inputs))
            if self._write_prompt:
                sys.stdout.write(prompt)
            if self._write_input:
                sys.stdout.write(_input + '\n')
            return _input
        except StopIteration:
            raise IOError('Received more calls to input() than expected!  (Your code called input() more times than was expected by the tester.)')

    def __enter__(self):
        builtins.input = self._fake_input

    def __exit__(self, *exc):
        builtins.input = self._realinput
        return False


def run_program(filename, inputs=[], write_input=True):
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload

    with contextlib.redirect_stdout(fake_stdout):
        with mocked_input(inputs, write_input):
            importlib.import_module(module_name)

    output = fake_stdout.getvalue()
    return output

def run_function(filename, func_name, func_args=[], inputs=[], write_prompt=True, write_input=True):
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload

    with contextlib.redirect_stdout(fake_stdout):
        with mocked_input(inputs, write_input):
            module = importlib.import_module(module_name)
            func = getattr(module, func_name)
            retval = func(*func_args)
            output = fake_stdout.getvalue()
    return output, retval

def get_parameter_count(filename, func_name):
    '''
    Assumes that filename is a path to python program. Imports it, adding the
    path to the file to sys.path if necessary.
    '''
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    clean_path = directory != '' and directory not in sys.path

    try:
        module_name = filename.replace('.py', '')
        sys.path.insert(0, directory)
        if module_name in sys.modules: # so ugly: check if already imported
            del sys.modules[module_name]  # force "hard" reload to clear namespace cache
        with contextlib.redirect_stdout(fake_stdout):
            ##with mocked_input(inputs, write_input):
            module = importlib.import_module(module_name)
            func = getattr(module, func_name)
            sig = inspect.signature(func)
            count = len(sig.parameters)
    except Exception:
        print(traceback.format_exc())
        count = -1
    finally:
        if clean_path:
            sys.path.remove(directory)
    return count

def deblank(s):
    return '\n'.join(line for line in s.split('\n') if line.strip() != '')


class TestProgram(unittest.TestCase):
    def compareProgramOutputs(self, program_name, template,
                              template_kwargs, program_inputs):
        msg = "\nError!  Expected to find a file named {0}\n"
        msg += "But could not find this file.  Make sure it\n"
        msg += "is located in the same folder as the test program."
        msg = msg.format(program_name)
        self.assertTrue(os.path.isfile(program_name), msg)
        expected = template.format(**template_kwargs)
        inputs = [template_kwargs[in_name] for in_name in program_inputs]
        student_output = run_program(program_name, inputs)
        expected = expected.strip()
        student_output = student_output.strip()
        msg = "\nUnexpected output executing: {0}\n"
        msg += "Expected to see this:\n\n{1}\n\n"
        msg += "Instead saw this:\n\n{2}\n"
        msg += "View a detailed output comparison in {0}.html."
        msg = msg.format(program_name, expected, student_output)

        try:
            os.unlink("{}.html".format(program_name))
        except:
            pass

        if expected != student_output:
            diff = difflib.HtmlDiff(tabsize=4, wrapcolumn=40).make_file(expected.splitlines(keepends=True),student_output.splitlines(keepends=True), fromdesc="Expected output", todesc="Your program's output")
            with open("{}.html".format(program_name), "w") as outfile:
                outfile.write(diff)

        self.assertEqual(expected, student_output, msg)

    def compareFunctionOutput(self, program_name, func_name, func_args, out_template, kwargs={}, inputs=[]):
        msg = "\nError!  Expected to find a file named {0}\n"
        msg += "But could not find this file.  Make sure it\n"
        msg += "is located in the same folder as the test program."
        msg = msg.format(program_name)
        self.assertTrue(os.path.isfile(program_name), msg)
        expected_out = out_template.format(**kwargs)
        inputs = [kwargs[in_name] for in_name in inputs]
        student_out, student_ret = run_function(program_name, func_name, func_args, inputs)
        msg = "\nError executing {0} {1}\n"
        msg += "Expected to see this:\n\n{2}\n\n"
        msg += "Instead saw this:\n\n{3}\n"
        msg += "View a detailed output comparison in {0}.html."
        msg = msg.format(program_name, func_name, expected_out, student_out)

        try:
            os.unlink("{}.html".format(func_name))
        except:
            pass

        if deblank(expected_out) != deblank(student_out):
            diff = difflib.HtmlDiff(tabsize=4, wrapcolumn=40).make_file(expected_out.splitlines(keepends=True),student_out.splitlines(keepends=True), fromdesc="Expected output", todesc="Your function's output")
            with open("{}.html".format(func_name), "w") as outfile:
                outfile.write(diff)

        self.assertEqual(deblank(expected_out), deblank(student_out), msg)

    def compareFunctionReturn(self, program_name, func_name, func_args, expected_ret, kwargs={}, inputs=[]):
        msg = "\nError!  Expected to find a file named {0}\n"
        msg += "But could not find this file.  Make sure it\n"
        msg += "is located in the same folder as the test program."
        msg = msg.format(program_name)
        self.assertTrue(os.path.isfile(program_name), msg)
        inputs = [kwargs[in_name] for in_name in inputs]
        student_out, student_ret = run_function(program_name, func_name, func_args, inputs)
        msg = "\nError executing {0} {1}\n"
        msg += "Expected return:\n\n{2}\n\n"
        msg += "Instead returned:\n\n{3}\n\n"
        msg += "Output:\n\n{4}\n\n"
        msg = msg.format(program_name, func_name, expected_ret, student_ret, student_out)
        self.assertEqual(expected_ret, student_ret, msg)


class TestCrateazon(TestProgram):

    def __init__(self, *args, **kwargs):
        super(TestCrateazon, self).__init__(*args, **kwargs)
        self.filename = 'hw8_crate-azon.py'

    def compare_load_inventory(self, inputs, expect_out, expect_ret):
        ''' Compares the expected output and return value of load_inventory to
        the student's output and return value'''
        func_name = 'load_inventory'
        func_args = []
        kwargs = {}
        for i in range(len(inputs)):
            kwargs['in'+str(i)] = inputs[i]
            inputs[i] = 'in'+str(i)
        self.compareFunctionOutput(self.filename, func_name, func_args, expect_out, kwargs, inputs)
        self.compareFunctionReturn(self.filename, func_name, func_args, expect_ret, kwargs, inputs)

    def test_load_inventory_single(self):
        output = '''Enter a category: {in0}'''
        inputs = ['electronics']
        ret = [['iPhone', 699.0]]
        self.compare_load_inventory(inputs, output, ret)

    def test_load_inventory_multiple(self):
        output = '''Enter a category: {in0}'''
        inputs = ['art']
        ret = [['Crayons', 1.99], ['Washable markers', 0.99], ['Permanent markers', 2.99]]
        self.compare_load_inventory(inputs, output, ret)

    def test_load_inventory_invalid(self):
        output = '''Enter a category: {in0}
Invalid category'''
        inputs = ['none']
        ret = []
        self.compare_load_inventory(inputs, output, ret)

    def compare_display_inventory(self, func_args, expect_out):
        ''' Compares the expected output of display_inventory to the student's 
        output'''
        func_name = 'display_inventory'
        self.compareFunctionOutput(self.filename, func_name, func_args, expect_out)

    def test_display_inventory_single(self):
        output = '''1. iPhone $699.00'''
        args = [[['iPhone', 699.0]]]
        self.compare_display_inventory(args, output)

    def test_display_inventory_multiple(self):
        output = '''1. Crayons $1.99
2. Washable markers $0.99
3. Permanent markers $2.99'''
        args = [[['Crayons', 1.99], ['Washable markers', 0.99], ['Permanent markers', 2.99]]]
        self.compare_display_inventory(args, output)

    def compare_select_items(self, inputs, expect_out, expect_ret, inventory_size):
        ''' Compares the expected output and return value of select_items to
        the student's output and return value'''
        func_name = 'select_items'
        func_args = [inventory_size]
        kwargs = {}
        for i in range(len(inputs)):
            kwargs['in'+str(i)] = inputs[i]
            inputs[i] = 'in'+str(i)
        self.compareFunctionOutput(self.filename, func_name, func_args, expect_out, kwargs, inputs)
        self.compareFunctionReturn(self.filename, func_name, func_args, expect_ret, kwargs, inputs)

    def test_select_items_single(self):
        output = '''Enter item numbers: {in0}'''
        inputs = ['1']
        ret = [1]
        self.compare_select_items(inputs, output, ret,3)

    def test_select_items_multiple(self):
        output = '''Enter item numbers: {in0}'''
        inputs = ['2;2;3']
        ret = [2,2,3]
        self.compare_select_items(inputs, output, ret, 3)

    def test_select_items_none(self):
        output = '''Enter item numbers: {in0}'''
        inputs = ['']
        ret = []
        self.compare_select_items(inputs, output, ret, 3)

    def test_select_items_invalid(self):
        output = '''Enter item numbers: {in0}
a is an invalid item number
100 is an invalid item number'''
        inputs = ['1;a;2;100;3']
        ret = [1,2,3]
        self.compare_select_items(inputs, output, ret, 3)

    def compare_display_summary(self, inventory, item_nums):
        ''' Compares the expected output of display_summary to the student's 
        output'''
        func_name = 'display_summary'
        func_args = [inventory, item_nums]
        expect_out = 'Your crate contains %d items:\n' % len(item_nums)
        expect_out += '-' * 10 + '\n'
        expect_out += '\n'.join(['%s: $%.02f' % (inventory[i-1][0], inventory[i-1][1]) for i in item_nums]) + '\n'
        expect_out += '-' * 10 + '\n'
        total = sum([inventory[i-1][1] for i in item_nums])
        expect_out += 'Item Total: $%.02f\n' % (total)
        shipping = 4.99 + ((len(item_nums) - 5) * 0.5 if len(item_nums) > 5 else 0)
        expect_out += 'Shipping: $%.02f\n' % (shipping)
        expect_out += '-' * 10 + '\n'
        expect_out += 'Order Total: $%.02f\n' % (total + shipping)
        self.compareFunctionOutput(self.filename, func_name, func_args, expect_out)

    def test_display_summary_single(self):
        inventory = [['Crayons', 1.99], ['Washable markers', 0.99], ['Permanent markers', 2.99]]
        item_nums = [2]
        self.compare_display_summary(inventory, item_nums)
            
    def test_display_summary_repeat(self):
        inventory = [['Crayons', 1.99], ['Washable markers', 0.99], ['Permanent markers', 2.99]]
        item_nums = [2, 2, 3]
        self.compare_display_summary(inventory, item_nums)

    def test_display_summary_seven(self):
        inventory = [['Crayons', 1.99], ['Washable markers', 0.99], ['Permanent markers', 2.99]]
        item_nums = [1, 1, 1, 1, 1, 1, 1]
        self.compare_display_summary(inventory, item_nums)

if __name__ == '__main__':
    unittest.main(verbosity=10)

# ----------------------------------------------------------
# --------               hw3 email validator       ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:  
# Hours spent on this program: 
# Collaborators and sources:
#   (List any collaborators or sources here.)
# With one exam and a few homeworks completed, how is the 
# course going for you so far?
#   (Please write a brief note here...)
# ----------------------------------------------------------

import string


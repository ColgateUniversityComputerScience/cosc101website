# ----------------------------------------------------------
# --------              hw4 water billing problem  ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this problem:
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------


# Write your python code for this problem below

## SEE THE HOMEWORK DESCRIPTION FOR HOW THESE FUNCTIONS SHOULD BE
## IMPLEMENTED

def valid_meter_reading(reading):
    pass

def water_used(begin, end):
    pass

def compute_bill_amount(code, usage):
    pass

def one_customer(custnumber):
    pass

def main():
    pass


# DO NOT modify the following two lines; they will interfere with the tester
if __name__ == '__main__':
    main()

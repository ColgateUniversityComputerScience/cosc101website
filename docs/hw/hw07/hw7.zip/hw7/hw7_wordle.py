# ----------------------------------------------------------
# --------              HW 7: Wordle             ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------


# Write your python program below:

import random

def get_vocab(f):
	"""
	Generates a word list (i.e., the vocabulary)
	Parameters:
		f (file object) open file object with five letter words 

	Returns:
		vocab (list) list of words
	""" 
	vocab = f.read().split()
	return(vocab)


def select_word(vocab):
	"""
	Selects a random word

	Parameters:
		vocab (list) collection of valid words 

	Returns:
		word (string) the randomly selected word
	"""

	return(random.choice(vocab))


def format_char(char, guess_type):
	"""
	Get the appropriate background for the character depending on the guess_type
	
	Parameters:
		- char (string) a string with one character. 
		- guess_type (string) three possibilities: '2', '1' or '0' (for correct, partial, incorrect)

	Returns:
		 A string with the appropriate background color: green if correct, yellow if partial and white otherwise. 
	"""
	if guess_type == '2': # fully correct
		new_char = '\033[1;30;42m {} \033[0;0m'.format(char)
	elif guess_type == '1': # partially correct
		new_char = '\033[1;30;43m {} \033[0;0m'.format(char)
	else: # incorrect
		new_char = '\033[1;30;47m {} \033[0;0m'.format(char)

	return(new_char)

## WRITE YOUR FUNCTIONS BELOW



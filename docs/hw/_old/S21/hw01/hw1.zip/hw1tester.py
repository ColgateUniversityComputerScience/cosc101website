#!/usr/bin/env python3

import sys
import os
import re
import importlib
import contextlib
import builtins
import unittest
import difflib
from io import StringIO


class mocked_input(contextlib.ContextDecorator):
    def __init__(self, inputs=[], write_prompt=True, write_input=True):
        self._inputs = iter(inputs)
        self._write_prompt = write_prompt
        self._write_input = write_input
        self._realinput = builtins.input

    def _fake_input(self, prompt=''):
        try:
            _input = str(next(self._inputs))
            if self._write_prompt:
                sys.stdout.write(prompt)
            if self._write_input:
                sys.stdout.write(_input + '\n')
            return _input
        except StopIteration:
            raise IOError('Received more calls to input() than expected!')

    def __enter__(self):
        builtins.input = self._fake_input
    
    def __exit__(self, *exc):
        builtins.input = self._realinput
        return False


def run_program(filename, inputs=[], write_input=True):
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload

    with contextlib.redirect_stdout(fake_stdout):
        with mocked_input(inputs, write_input):
            importlib.import_module(module_name)

    output = fake_stdout.getvalue()
    return output


class TestProgram(unittest.TestCase):
    """
    Base class for COSC101 tests
    """

    def compareProgramOutputs(self, program_name, template,
                              template_kwargs, program_inputs):
        msg = "\nError!  Expected to find a file named {0}\n"
        msg += "But could not find this file.  Make sure it\n"
        msg += "is located in the same folder as the test program."
        msg = msg.format(program_name)
        self.assertTrue(os.path.isfile(program_name), msg)
        expected = template.format(**template_kwargs)
        inputs = [template_kwargs[in_name] for in_name in program_inputs]
        student_output = run_program(program_name, inputs)
        expected = expected.strip()
        student_output = student_output.strip()
        msg = "\nUnexpected output executing: {0}\n"
        msg += "Expected to see this:\n\n{1}\n\n"
        msg += "Instead saw this:\n\n{2}\n"
        msg += "View a detailed output comparison in {0}.html."
        msg = msg.format(program_name, expected, student_output)

        try:
            os.unlink("{}.html".format(program_name))
        except:
            pass

        if expected != student_output:
            diff = difflib.HtmlDiff(tabsize=4, wrapcolumn=40).make_file(expected.splitlines(keepends=True),student_output.splitlines(keepends=True), fromdesc="Expected output", todesc="Your program's output")
            with open("{}.html".format(program_name), "w") as outfile:
                outfile.write(diff)

        self.assertEqual(expected, student_output, msg)


class TestTypes(TestProgram):
    def test_types(self, *args):
        filename = 'hw1_types.py'
        template = '''<class 'int'>
<class 'int'>
<class 'int'>
<class 'str'>
<class 'str'>
<class 'float'>
18b18b18b18b18b18b
0
'''
        self.compareProgramOutputs(filename, template, {}, [])


class TestMadLibs(TestProgram):
    def compare(self, *args):
        filename = 'hw1_madlibs.py'
        names = ['noun', 'verb1', 'verb2']
        kwargs = dict(zip(names,args))
        template = '''What's the noun? {noun}
What's the first verb? {verb1}
What's the second verb? {verb2}
If it {verb1} like a {noun} and {verb2} like a {noun}, it probably is a {noun}.
'''
        self.compareProgramOutputs(filename, template, kwargs, names)

    def test_example_01(self):
        self.compare('duck','walks','talks')

    def test_example_02(self):
        self.compare('dragon','eats tacos','breathes fire')


class TestGardenDesign(TestProgram):
    def compare(self, *args):
        filename = 'hw1_garden.py'
        template = '''Enter length of side of garden (feet): {sidelen}
Enter spacing between plants (feet): {plantspacing}
Enter depth of garden soil (feet): {soildepth}
Enter depth of fill (feet): {filldepth}

Plants for each semicircle garden: {semiplants}
Plants for the circle garden: {circleplants}
Total plants for garden: {totalplants}
Soil for each semicircle garden: {semisoil} cubic yards
Soil for the circle garden: {circlesoil} cubic yards
Total soil for the garden: {totalsoil} cubic yards
Total fill for the garden: {totalfill} cubic yards
'''
        names = ['sidelen', 'plantspacing', 'soildepth', 'filldepth',
                 'semiplants', 'circleplants', 'totalplants', 'semisoil',
                 'circlesoil', 'totalsoil', 'totalfill']
        kwargs = dict(zip(names, args))
        self.compareProgramOutputs(filename, template, kwargs, ['sidelen', 'plantspacing', 'soildepth', 'filldepth'])

    def test_example_01(self):
        self.compare(10, 0.5, 0.8333, 0.8333, 39, 78, 234, 0.3, 0.6, 1.8, 1.3)

    def test_example_02(self):
        self.compare(13, 0.25, 0.5, 0.25, 265, 530, 1590, 0.3, 0.6, 1.8, 0.6)


class TestRoadTrip(TestProgram):
    def compare(self, *args):
        filename = 'hw1_roadtrip.py'
        names = ['name', 'dist', 'speed', 'days', 'hours', 'minutes', 'seconds']
        kwargs = dict(zip(names,args))
        template = '''Who is driving? {name}
How far away is the destination (in miles)? {dist}
How fast is {name} driving (in mph)? {speed}
It will take {name} {days} days, {hours} hours, {minutes} minutes, and {seconds} seconds.
'''
        self.compareProgramOutputs(filename, template, kwargs, ['name', 'dist', 'speed'])

    def test_example_01(self):
        self.compare('Jack K.', '3000', '50', 2, 12, 0, 0)

    def test_example_02(self):
        self.compare('Ryan.', '120', '30', 0, 4, 0, 0)



if __name__ == '__main__':
    unittest.main(verbosity=3)

import sys
import os
import re
import importlib
import contextlib
import unittest
import difflib
import webbrowser
import ast
import builtins
from io import StringIO


class mocked_input(contextlib.ContextDecorator):
    def __init__(self, inputs=[], write_prompt=True, write_input=True):
        self._inputs = iter(inputs)
        self._write_prompt = write_prompt
        self._write_input = write_input
        self._realinput = builtins.input

    def _fake_input(self, prompt=''):
        try:
            _input = str(next(self._inputs))
            if self._write_prompt:
                sys.stdout.write(prompt)
            if self._write_input:
                sys.stdout.write(_input + '\n')
            return _input
        except StopIteration:
            raise IOError('Received more calls to input() than expected!  (Your code called input() more times than was expected by the tester.)')

    def __enter__(self):
        builtins.input = self._fake_input
    
    def __exit__(self, *exc):
        builtins.input = self._realinput
        return False

        
def run_program(filename, inputs=[], write_input=True):
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload

    with contextlib.redirect_stdout(fake_stdout):
        with mocked_input(inputs, write_input):
            importlib.import_module(module_name)

    output = fake_stdout.getvalue()
    return output


class COSC101TestResult(unittest.TextTestResult):
    """
    Make somewhat tidier output than the built-in TextTestResult classs
    """

    def printErrorList(self, flavour, errors):
        for test, err in errors:
            self.stream.writeln(self.separator1)
            self.stream.writeln("%s: %s" % (flavour, self.getDescription(test)))
            self.stream.writeln(self.separator2)
            mobj = re.search("(unexpected output)", err, re.I)
            if mobj:
                startidx = mobj.start(0)
                err = err[startidx:]
            else:
                lines = err.split('\n')
                i = len(lines) - 1
                while i >= 0:
                    if re.search('importlib', lines[i], re.I):
                        i += 1
                        break
                    i -= 1
                err = '\n'.join(lines[i:])
            self.stream.writeln("%s " % err)


class TestProgram(unittest.TestCase):
    def compareProgramOutputs(self, program_name, template,
                              template_kwargs, program_inputs):
        msg = "\nError!  Expected to find a file named {0}\n"
        msg += "But could not find this file.  Make sure it\n"
        msg += "is located in the same folder as the test program."
        msg = msg.format(program_name)
        self.assertTrue(os.path.isfile(program_name), msg)
        expected = template.format(**template_kwargs)
        inputs = [template_kwargs[in_name] for in_name in program_inputs]
        student_output = run_program(program_name, inputs)
        expected = expected.strip()
        student_output = student_output.strip()
        htmlout = program_name + ".html"
        if os.path.exists(htmlout):
            os.unlink(htmlout)

        msg = "\nUnexpected output executing: {0}\n"
        msg += "Expected to see this:\n\n{1}\n\n"
        msg += "Instead saw this:\n\n{2}\n"
        msg += "View a detailed output comparison in {3}."
        msg = msg.format(program_name, expected, student_output, htmlout)

        if expected != student_output:
            diff = difflib.HtmlDiff(tabsize=4, wrapcolumn=40).make_file(expected.splitlines(keepends=True),student_output.splitlines(keepends=True), fromdesc="Expected output", todesc="Your program's output")
            with open("{}.html".format(program_name), "w") as outfile:
                outfile.write(diff)

        self.assertEqual(expected, student_output, msg)


class TestDoy(TestProgram):
    def compare(self, doy, month, dom, error=None):
        '''Compares the expected result to the student's result
            doy - day of year to check
            month - month in which day of year falls
            dom - day of month on which day of year falls
        '''
        filename = 'hw2_doy.py'

        if (error is None):
            template = '''Enter the day of the year: {doy}
Day {doy} is {month} {dom}
            '''
            kwargs = { 'doy' : doy, 'month' : month, 'dom' : dom }
        else:
            template = '''Enter the day of the year: {doy}
{error}
            '''
            kwargs = { 'doy' : doy, 'error' : error }

        program_inputs = ['doy']
        self.compareProgramOutputs(filename, template, kwargs, program_inputs)

    def test_mid_january(self):
        self.compare(15, 'January', 15)

    def test_february_first(self):
        self.compare(31+1, 'February', 1)

    def test_mid_march(self):
        self.compare(31+28+15, 'March', 15)


class TestTaxes(TestProgram):
    def compare(self, gross, deduction, taxes):
        '''Compares the expected result to the student's result
           gross - gross income
           deduction - total deduction
           taxes - amount of taxes owed
        '''
        filename = 'hw2_taxes.py'
        template = '''What is your gross income? {gross}
What is your total deduction? {deduction}
Your taxable income is ${taxable}
You owe ${taxes} in federal taxes
        '''
        kwargs = { 'gross' : gross, 'deduction' : deduction, 
                'taxable' : gross - deduction, 'taxes' : taxes }
        program_inputs = ['gross', 'deduction']
        self.compareProgramOutputs(filename, template, kwargs, program_inputs)

    def test_deduction(self):
        self.compare(9000, 1000, (9000 - 1000) * 0.1)

    def test_lowest(self):
        self.compare(5000, 0, 5000 * 0.1)

    def test_second(self):
        self.compare(10000, 0, (10000 - 9700) * 0.12 + 970)

    def test_fifth(self):
        self.compare(222000, 0, (222000 - 204100) * 0.35 + 46628)


class IfStatement(object):
    def __init__(self, node, source):
        self._line = node.lineno
        self._haselse = False
        self._elif_count = 0
        self._parse_stmt_tree(node, source)

    def _parse_stmt_tree(self, node, source):
        def _follow_else(n, offset):
            self._elif_count += 1
            # if there are no If objects in n.orelse and it is non-empty, set haselse
            exprct = subifct = 0
            for b in n.orelse:
                if isinstance(b, ast.If) and b.col_offset == offset:
                    subifct += 1
                    token = source[b.lineno-1].strip().split()[0]
                    if token.startswith('elif'):
                        return _follow_else(b, offset)
                else:
                    exprct += 1
            return (exprct + subifct > 0 and exprct > 0 and subifct == 0)

        exprct = subifct = 0
        for b in node.orelse:
            if isinstance(b, ast.If):
                subifct += 1
                token = source[b.lineno-1].strip().split()[0]
                if token.startswith('elif'):
                    self._haselse = _follow_else(b, b.col_offset)
            else:
                exprct += 1
        if subifct == 0:
            self._haselse = exprct + subifct > 0 and exprct > 0

    def get_info(self):
        return (self._elif_count, self._haselse)

    def __str__(self):
        return "{}: {} elifs, {}".format(self._line, self._elif_count, self._haselse)


class AdventureTests(TestProgram):
    def testIfStatements(self):
        filename = 'hw2_adventure.py'

        with open(filename) as infile:
            source = infile.read()
        with open(filename) as infile:
            sourcelines = infile.readlines()

        tree = ast.parse(source, filename)
        ifstmts = [i for i in ast.walk(tree) if isinstance(i, ast.If)]
        ifobj = []
        for stmt in ifstmts:
            if sourcelines[stmt.lineno-1].strip().startswith('if'):
                ifs = IfStatement(stmt, sourcelines)
                ifobj.append(ifs)

        found_ifs = list(reversed(sorted([i.get_info() for i in ifobj])))
        needed = [
                (lambda xelif: xelif >= 2, True, "at least 2 elifs and an else"),
                (lambda xelif: xelif == 1, True, "exactly 1 elif and an else"), 
                (lambda xelif: xelif >= 1, False, "at least 1 elif but no else"),
                (lambda xelif: xelif == 0, True, "no elif's but an else"), 
                (lambda xelif: xelif == 0, False, "no elif's and no else")
                ]

                
        not_found = []
        for predicate, haselse, desc in needed:
            found = False
            for numelifs, observedelse in found_ifs:
                if predicate(numelifs) and haselse == observedelse:
                    print("Adventure: Found an if statement with", desc)
                    found = True
            if not found:
                not_found.append(desc)

        for s in not_found:
            msg = "Adventure: Missing an if statement with {}".format(s)
            print(msg)
        self.assertTrue(len(not_found) == 0)


if __name__ == '__main__':
    unittest.main(verbosity=0, testRunner=unittest.TextTestRunner(resultclass=COSC101TestResult))

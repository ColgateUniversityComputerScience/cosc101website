# ----------------------------------------------------------
# --------             HW 8: hangperson            ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after you have completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this problem:
#
# Collaborators and sources:
#   (List any collaborators or sources here.)
#
# ----------------------------------------------------------

# Complete the code below for hangperson


import random

# you can just _use_ this function in your code; you should not
# make any changes to it
def print_gallows(num_missed):
    '''
    Make a poor-human's representation of the hangperson gallows.
    Parameter to the function is the number of missed words (7 misses
    means that the player is fully strung up).
    '''
    print()
    print()
    print('       |||========|||')
    if num_missed > 0:
        print('       |||         |')
    else:
        print('       |||          ')

    if num_missed > 1:
        print('       |||         O')
    else:
        print('       |||          ')

    if num_missed > 2:
        if num_missed > 4:
            print('       |||        /|\\')
        elif num_missed > 3:
            print('       |||        /| ')
        else:
            print('       |||        /  ')
    else:
        print('       |||           ')

    if num_missed > 5:
        if num_missed > 6:
            print('       |||        / \\')
        else:
            print('       |||        /  ')
    else:
        print('       |||           ')

    print('       |||')
    print('       |||')
    print('     =================')
    print()


# your code should go between here and main


def one_game(secret):
    pass
    # your code for this function should start here (you can remove
    # the "pass" above


def main():
    '''() -> ()

    main function for playing hangperson
    '''
    words = ['PUMPKIN', 'ELECTION', 'VOTE', 'CLIMATE', 'CHANGE']
    secret = random.choice(words)
    print("For testing, the secret word is", secret)
    one_game(secret)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    main()

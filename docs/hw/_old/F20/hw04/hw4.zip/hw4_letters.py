# ----------------------------------------------------------
# --------               hw4 retro font            ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:  
# Hours spent on this program: 
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------


import block_paint

# set an arbitrary scale; you should ask the user for the scale
scale = 13

# make a new window to draw in
window = block_paint.new_grid(scale)

# draw two vertical lines
for i in range(scale):
    window.paint(0, i, 'red')
    window.paint(scale-1, i, 'blue')

# all done drawing
window.end()

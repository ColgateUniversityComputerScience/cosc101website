import sys
import os
import re
import importlib
import contextlib
import unittest
import difflib
import webbrowser
import builtins
from io import StringIO


class mocked_input(contextlib.ContextDecorator):
    def __init__(self, inputs=[], write_prompt=True, write_input=True):
        self._inputs = iter(inputs)
        self._write_prompt = write_prompt
        self._write_input = write_input
        self._realinput = builtins.input

    def _fake_input(self, prompt=''):
        try:
            _input = str(next(self._inputs))
            if self._write_prompt:
                sys.stdout.write(prompt)
            if self._write_input:
                sys.stdout.write(_input + '\n')
            return _input
        except StopIteration:
            raise IOError('Received more calls to input() than expected!  (Your code called input() more times than was expected by the tester.)')

    def __enter__(self):
        builtins.input = self._fake_input
    
    def __exit__(self, *exc):
        builtins.input = self._realinput
        return False

        
def run_program(filename, inputs=[], write_input=True):
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload

    with contextlib.redirect_stdout(fake_stdout):
        with mocked_input(inputs, write_input):
            importlib.import_module(module_name)

    output = fake_stdout.getvalue()
    return output


class TestProgram(unittest.TestCase):
    def compareProgramOutputs(self, program_name, template,
                              template_kwargs, program_inputs):
        msg = "\nError!  Expected to find a file named {0}\n"
        msg += "But could not find this file.  Make sure it\n"
        msg += "is located in the same folder as the test program."
        msg = msg.format(program_name)
        self.assertTrue(os.path.isfile(program_name), msg)
        expected = template.format(**template_kwargs)
        inputs = [template_kwargs[in_name] for in_name in program_inputs]
        student_output = run_program(program_name, inputs)
        expected = expected.strip()
        student_output = student_output.strip()
        htmlout = program_name + ".html"
        if os.path.exists(htmlout):
            os.unlink(htmlout)

        msg = "\nUnexpected output executing: {0}\n"
        msg += "Expected to see this:\n\n{1}\n\n"
        msg += "Instead saw this:\n\n{2}\n"
        msg += "View a detailed output comparison in {3}."
        msg = msg.format(program_name, expected, student_output, htmlout)

        if expected != student_output:
            diff = difflib.HtmlDiff(tabsize=4, wrapcolumn=40).make_file(expected.splitlines(keepends=True),student_output.splitlines(keepends=True), fromdesc="Expected output", todesc="Your program's output")
            with open("{}.html".format(program_name), "w") as outfile:
                outfile.write(diff)

        self.assertEqual(expected, student_output, msg)

class TestEmail(TestProgram):

    filename = 'hw4_email.py'

    def compare_valid(self, email, local, domain):
        template = '''Enter an email: {email}
Valid email
Local part: {local}
Domain part: {domain}
'''
        kwargs = dict(email=email, local=local, domain=domain)
        self.compareProgramOutputs(TestEmail.filename, template, kwargs, ['email'])

    def compare_colgate(self, email, local, domain):
        template = '''Enter an email: {email}
Valid email
Local part: {local}
Domain part: {domain}
From COLGATE!
'''
        kwargs = dict(email=email, local=local, domain=domain)
        self.compareProgramOutputs(TestEmail.filename, template, kwargs, ['email'])

    def compare_invalid(self, email):
        template = '''Enter an email: {email}
Invalid email
'''
        kwargs = dict(email=email)
        self.compareProgramOutputs(TestEmail.filename, template, kwargs, ['email'])

    def test_example_01(self):
        self.compare_invalid('ef@col@gate.edu')
    def test_example_02(self):
        self.compare_invalid('@colgate.edu')
    def test_example_03(self):
        self.compare_invalid('joe@')
    def test_example_04(self):
        self.compare_invalid('joe')
    def test_example_05(self):
        self.compare_invalid('dog@ab?c')
    def test_example_06(self):
        self.compare_invalid('apple@ab')

    def test_example_07(self):
        self.compare_colgate('bcasey@colgate.edu', 'bcasey', 'colgate.edu')
    def test_example_08(self):
        self.compare_valid('e@colgate.com', 'e', 'colgate.com')
    def test_example_09(self):
        self.compare_valid('emrys@colgate.ca', 'emrys', 'colgate.ca')
    def test_example_10(self):
        self.compare_valid('e@colgate', 'e', 'colgate')
    def test_example_11(self):
        self.compare_valid('e_f@colgate', 'e_f', 'colgate')

if __name__ == '__main__':
    unittest.main(verbosity=3)

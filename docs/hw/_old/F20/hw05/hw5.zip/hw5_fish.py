# ----------------------------------------------------------
# --------             HW 5: Part 2: fish text art ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after you have completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this problem:
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------

# Write your python program for this problem below:


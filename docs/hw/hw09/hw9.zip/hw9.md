# COSC 101 Homework 9; Spring 2022

The due date for this homework is **Thursday, April 28, 5:00pm EDT**.

This assignment is designed to give you practice with the following topics:

- Program design
- File I/O
- Lists
- Dictionaries
- Exceptions

# Introduction

**Sentiment Analysis** is the machine learning task of determining the opinion conveyed in a piece of text. For example, sentiment analysis can be used to determine whether a written product review is positive, negative, or neutral. 

Many approaches have been used for sentiment analysis. The simplest approach uses a lexicon -- a dictionary where words are associated with sentiments. For example, words like good and excellent are associated with a positive sentiment, while words like wrong and awful are associated with negative sentiment. The sentiment of the entire text is given by the count of positive and negative words. The sentence is positive if there are more positive than negative words; negative if there are more negative than positive words, and neutral if there is a tie. 

In this homework, you will complete a program that uses emojis for sentiment analysis. This will involve processing existing texts (tweets!) to build a lexicon and then using this lexicon to predict the emojis that likely apply to new texts. 

# Instructions

Download [`hw9.zip`](hw9.zip) and unzip the compressed file to reveal the following files included with this assignment:

- `hw9.pdf`: this description
- `data.txt`: file with one text (tweet) per line
- `hw9.py`: starting code

All of your work for this assignment will be completed in the file
`hw9.py`.  As with other assignments, this file has a special header at the top with form fields that you should fill out before submitting the code for this assignment.  Also, do not change the file name, as we sometimes
use programs to test your code. These test programs will not be able to find your program
and give you any credit if your file is named incorrectly.

## Required functionality

This homework is split into five steps. You will need to implement a function for three of the five steps. These functions are `create_training_set`, `bag_of_words` and `main`. 

For `create_training_set` and `bag_of_words`, there are provided doctests that can help you test your program.  We strongly recommend using the provided doctests and writing your own doctests to test other cases. You can run the doctests for all functions in the  `hw9.py` file with the following command:

```bash
python -m doctest hw9.py
```

Running the doctest with the provided starter code (before you start programming) will produce 5 failures, most of them corresponding to runtime exceptions. 


## Step 1: Create the dataset

The `create_training_set` function should convert a list of texts containing emojis into a dictionary. The dictonary should have emoji keys and values that are lists of texts with emojis removed. 

For example, if the list contains only three texts 

```
["axa 🙏 bb 🥰", "🥰 cc axa", "xx 🥺 z"]
```

the `create_training_set` function should produce the dictionary 

```
{'🙏': ['axa  bb '], '🥰': ['axa  bb ', ' cc axa'], '🥺': ['xx  z']}
```

This is because the 🥰 emoji occurred in texts `'axa bb'` and `' cc axa'` with emojis removed. 

You only need to worry about the emojis included in the `EMOJIS` list at the top of the `hw9.py` file. These commonly-used emojis are the only ones that will appear in the dataset you will use for sentiment analysis. 

Remember to use the provided doctest for the `create_training_set` function to test your code. You are also encouraged to add additional doctests to test other cases. 


## Step 2: Word Count

The `bag_of_words` function should count the number of times any given word occurs in a list of texts. This produces a "bag of words" model which only considers the number of each word and not the word order. 

 For example, if `bag_of_words` is given the list 

 ```
['axa bb ', 'bb z']
 ```

it should produce the dictionary

```
{'axa': 1, 'bb': 2, 'z':1}
```

because the word `'bb'` occurs twice across the texts in the list. You can assume that words will be separated by spaces. 

Remember to use the provided doctest for the `bag_of_words` function to test your code. You are also encouraged to add additional doctests to test other cases. 


## Step 3: Training (Provided)

The `train` function, which has been provided for you, applies the `bag_of_words` function to the output of the `create_training_set` function. 

 For example, let 

 ```
 {'🙏': ['axa bb ', 'bb z'], '🥰': [' cc axa'], '🥺': ['xx z']}
 ```

be the output of `create_training_set`. The `train` function will take this dictionary and produce

```
{'🙏': {'axa': 1, 'bb': 2, 'z':1},  '🥰': {'cc':1 , 'axa': 1}, '🥺': {'xx': 1, 'z': 1}}
```

where the lists of texts have been converted into dictionaries of word counts. 

**Reminder:** You do not need to modify anything in `train`. If you have implemented `create_training_set` and `bag_of_words` correctly, the `train` doctests will pass.


## Step 4: Prediction (Provided)

The `predict` function, which has been provided for you, takes a trained model and a new text without emojis. The function predicts what emojis most likely apply to the text. It does this by matching the words in the text to the words in the dictionaries `train`. Trace through the `predict` function to make sure you understand how it works. 

**Reminder:** You do not need to modify anything in `predict`. If you have implemented `create_training_set` and `bag_of_words` correctly, the `predict` doctests will pass


## Step 5: main() function

The final step is to create a `main` function that does the following:

  1. Read a list of texts stored in a file called `data.txt`. The file has one text per line, and each text contains at least one emoji 
  2. Use the `train` function to create a model from the list of texts
  3. Iteratively asks the user to provide a new text and use the `predict` function to predict what emojis best fit the text
  4. Print the predicted emojis to the screen

For example, if the user enters 

```
HI everyone, Good afternoon
```

when prompted, the program should print 

```
{'😭': 1, '😍': 1, '🥰': 3, '🙏': 2, '🤣': 1}
```

To indicate that the 🥰 emoji is the best fit for the text, while the others are slightly worse fits. 


# Submission Instructions

Please upload your `hw9.py` file.

Remember to complete the questions at the top of the `hw9.py` file and that the file you submit needs to have this exact filename.

# Grading

Your assignment will be graded on two criteria:

1. Correctness: [75%].
   The correctness part of your grade is broken down as follows:

    | Category (function) | Portion of grade |
    | --- | --- |
    | Correctly create the training set | 30% |
    | Correctly train the model | 30% |
    | Correctly develop the main function | 15% |

2.  Program design and style [25%]. For this assignment, you are tasked with
completing three functions within each function:

    - Variable names should be meaningful

    - Code should contain at least a few descriptive comments if it is complex.  Do *not* comment every line of code with low level explanations of what each line does.  Focus on high level ideas.  You will **lose points** if you document every line of the file.

    - Functions should contain meaningful docstrings.

## Academic Integrity Note
The instructors are aware that there are "solutions" for some aspects of this homework on Internet sites. Remember that copying code from such "solutions" is against syllabus policies and constitutes an academic honor code violation.

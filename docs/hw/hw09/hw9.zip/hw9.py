# ----------------------------------------------------------
# --------     HW 9: Sentiment Analysis            ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after you have completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this problem:
#
# Collaborators and sources:
#   (List any collaborators or sources here.)
#
# ----------------------------------------------------------


EMOJIS = ['😂', '😭', '🤣', '🥺', '😍', '🔥', '🥰', '🙏']


def create_training_set(data):
    """Create a training set using a list of text
    >>> create_training_set(['good morning 😂🤣',  'hi 😂😍'])
    {'😂': ['good morning ', 'hi '], '🤣': ['good morning '], '😍': ['hi ']}
    """


def bag_of_words(texts, output):
    """Create a Bag of Words using the list of texts,
    the output is a dictionary that contains the frequency
    of the words

    >>> out = dict()
    >>> bag_of_words(['aa bb cc ', 'c cC'], out)
    >>> print(out)
    {'aa': 1, 'bb': 1, 'cc': 2, 'c': 1}
    """


def train(training_set):
    """Train the algorithm using Bag of Words
    >>> X = create_training_set(['Good morning 😂🤣',  'hi 😂😍'])
    >>> train(X)
    {'😂': {'good': 1, 'morning': 1, 'hi': 1}, '🤣': {'good': 1, 'morning': 1}, '😍': {'hi': 1}}
    """
    model = dict()
    for k, lines in training_set.items():
        try:
            bow = model[k]
        except KeyError:
            bow = dict()
            model[k] = bow
        bag_of_words(lines, bow)
    return model


def predict(model, txt):
    """Predict
    >>> X = create_training_set(['Good morning 😂🤣',  'hi 😂😍'])
    >>> model = train(X)
    >>> predict(model, 'HI everyone, Good afternoon')
    {'😂': 2, '😍': 1, '🤣': 1}
    """
    output = dict()
    for l in txt.split():
        l = l.lower().strip()
        for k, v in model.items():
            if l in v:
                output[k] = output.get(k, 0) + v[l]
    return output


def main():
    """Ask the user for a text to be predicted and outputs 
    the prediction.
    """


if __name__ == '__main__':
    main()

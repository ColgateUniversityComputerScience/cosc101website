# ----------------------------------------------------------
# --------              HW 2: Part 3               ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after having completed this
# program
# ----------------------------------------------------------
# Name:
# Hours spent on this part:
# Collaborators and sources:
#   (List any collaborators or sources here.)
# ----------------------------------------------------------


# Write your python program below:

## Import required modules

import turtle
import math

## Get user input

#### [WRITE THE NECESSARY CODE TO GET THE INPUT HERE]


## Create a window (note needs to happen after input)

wn = turtle.Screen() 

## [WRITE THE REMAINDER OF YOUR CODE HERE]



# the following line keeps the window open until the use clicks again. 
wn.exitonclick()                # wait for a user click on the canvas



#!/usr/bin/env python3

__author__ = "jsommers@colgate.edu"
__doc__ = '''
Simple library for painting blocks on a (by default, square) gridded window.  
Also includes some testing capabilities (a "fake" block painter).
'''

import sys
import tkinter

import os
import re
import importlib
import contextlib
import unittest
from unittest.mock import MagicMock
import builtins
from io import StringIO


class InvalidDimension(Exception):
    pass

class InvalidXValue(InvalidDimension):
    pass

class InvalidYValue(InvalidDimension):
    pass

class BlockPainter(tkinter.Frame):
    '''
    The main graphical frame that wraps up the buttons and canvas for
    drawing the blocks on screen. 
    '''
    def __init__(self, scale):
        self.root = tkinter.Tk()
        tkinter.Frame.__init__(self, self.root)
        self.root.title('Block Painter')
        self.width = scale  # make a square
        self.height = scale
        self.pix_per_block = 20
        self._createWidgets()
        self.pack()

    def _createWidgets(self):
        self.quit = tkinter.Button(self, text="Quit", command=self.quit)
        self.quit.pack(anchor="n",fill="x")

        self.canvas = tkinter.Canvas(self)
        self.canvas["width"] = (self.width) * self.pix_per_block + 1
        self.canvas["height"] = (self.height) * self.pix_per_block + 1
        self.canvas["relief"] = 'raised'
        self.canvas.pack(anchor="s",fill="both",padx=10)
        self.canvas.xview_moveto(0)
        self.canvas.yview_moveto(0)
        self.canvas.create_rectangle(0, 0,
                                     self.width*self.pix_per_block,
                                     self.width*self.pix_per_block)
        # grid lines
        for i in range(self.width+1):
            self.canvas.create_line(i*self.pix_per_block, 
                                    0,
                                    i*self.pix_per_block, 
                                    self.width*self.pix_per_block-1)
            self.canvas.create_line(0, 
                                    i*self.pix_per_block,
                                    self.width*self.pix_per_block-1,
                                    i*self.pix_per_block)


    def paint(self, x, y, color):
        '''Paint the block with coordinates (x,y) the given color.
        Raise an exception if x,y or color are invalid.'''

        if not isinstance(x, int):
            raise InvalidXValue("x must be an int but is a {}".format(type(x)))
        if not isinstance(y, int):
            raise InvalidYValue("y must be an int but is a {}".format(type(y)))

        if not (0 <= x < self.width):
            raise InvalidXValue("X dimension {} is invalid".format(x))
        if not (0 <= y < self.height):
            raise InvalidYValue("Y dimension {} is invalid".format(y))

        # make origin be at lower left
        y = self.height - y - 1

        self.canvas.create_rectangle(x*self.pix_per_block, y*self.pix_per_block, 
                                    (x+1)*self.pix_per_block, (y+1)*self.pix_per_block,
                                    fill=color)

    def end(self):
        self.root.mainloop()
        try:
            self.root.destroy()
        except:
            pass

def new_grid(scale):
    '''Make a new grid canvas, scale blocks wide and scale blocks high'''
    if not isinstance(scale, int):
        raise InvalidDimension("scale is invalid for creating a new grid; it must be an integer but is {}".format(type(scale)))
    return BlockPainter(scale)


# default name of file to be tested
FILENAME = 'hw4_letters.py'


class FakeBlockPainter(object):
    '''
    The main graphical frame that wraps up the buttons and canvas for
    drawing the blocks on screen. 
    '''
    def __init__(self, scale):
        self._width = scale  
        self._height = scale
        self._grid = {}
        for row in range(scale):
            for col in range(scale):
                self._grid[(row,col)] = ' '

    def paint(self, x, y, color):
        '''Paint the block with coordinates (x,y) the given color.
        Raise an exception if x,y or color are invalid.'''

        if not isinstance(x, int):
            raise InvalidXValue("x must be an int but is a {}".format(type(x)))
        if not isinstance(y, int):
            raise InvalidYValue("y must be an int but is a {}".format(type(y)))

        if not (0 <= x < self._width):
            raise InvalidXValue("X dimension {} is invalid".format(x))
        if not (0 <= y < self._height):
            raise InvalidYValue("Y dimension {} is invalid".format(y))

        # make origin be at lower left
        y = self._height - y - 1
        self._grid[(y,x)] = 'x'

    def _print_grids(self, other):
        lines = []
        lines.append("\nyour letter\texpected letter")
        lines.append("-----------\t---------------")
        for i in range(self._width):
            drawn = ""
            expected = ""
            for j in range(self._height):
                drawn += self._grid[(i,j)]
                expected += other[i][j]
            lines.append("{}\t\t{}".format(drawn, expected))
        return '\n'.join(lines)
                
    def compare_with(self, expected):
        for i in range(self._width):
            for j in range(self._height):
                if self._grid[(i,j)] != expected[i][j]:
                    return False, self._print_grids(expected)
        return True, ''

    def end(self):
        pass


class mocked_input(contextlib.ContextDecorator):
    def __init__(self, inputs=[], write_prompt=True, write_input=True):
        self._inputs = iter(inputs)
        self._write_prompt = write_prompt
        self._write_input = write_input
        self._realinput = builtins.input

    def _fake_input(self, prompt=''):
        try:
            _input = str(next(self._inputs))
            if self._write_prompt:
                sys.stdout.write(prompt)
            if self._write_input:
                sys.stdout.write(_input + '\n')
            return _input
        except StopIteration:
            raise IOError('Received more calls to raw_input than expected!')

    def __enter__(self):
        builtins.input = self._fake_input
    
    def __exit__(self, *exc):
        builtins.input = self._realinput
        return False

        
def run_program(filename, inputs=[], write_input=True):
    fake_stdout = StringIO()
    assert filename.endswith('.py')
    directory, filename = os.path.split(filename)
    module_name = filename.replace('.py', '')
    sys.path.insert(0, directory)
    if module_name in sys.modules:    # so ugly: check if already imported
        del sys.modules[module_name]  # force "hard" reload

    with contextlib.redirect_stdout(fake_stdout):
        with mocked_input(inputs, write_input):
            importlib.import_module(module_name)

    output = fake_stdout.getvalue()
    return output


class InvalidInput(Exception):
    pass


class TestProgram(unittest.TestCase):
    def badInputExample(self, program_name, program_inputs, msg):
        '''
        Run program_name, give the various inputs, and
        expect no calls to get made into block_paint at all.
        '''
        self.assertTrue(os.path.isfile(program_name))
        with unittest.mock.patch('block_paint.new_grid') as fakenewgrid:
            student_output = run_program(program_name, program_inputs)
            if fakenewgrid.called:
                raise InvalidInput(msg)

    def expectSuccess(self, program_name, program_inputs, expected):
        '''
        Run program_name, give it the scale and letter, and
        expect it to successfully draw the letter.
        '''
        self.assertTrue(os.path.isfile(program_name))
        scale = int(program_inputs[0])
        bp = FakeBlockPainter(scale)
        ng = MagicMock(return_value=bp)
        with unittest.mock.patch('block_paint.new_grid', new=ng):
            student_output = run_program(program_name, program_inputs)
            ng.assert_called_once_with(scale)
            equal, msg = bp.compare_with(expected)
            self.assertTrue(equal, msg)


class TestRetroLetters(TestProgram):
    def testBadScale1(self):
        '''
        Run blockpaint with bad scale (too low)
        '''
        program_inputs = ['2']
        self.badInputExample(FILENAME, program_inputs, "An invalid scale of 2 was given as input.  Your program should *not* call block_paint.new_grid in this case, but it did.")

    def testBadScale2(self):
        '''
        Run blockpaint with bad scale (not odd)
        '''
        program_inputs = ['4']
        self.badInputExample(FILENAME, program_inputs, "An invalid scale of 4 was given as input.  Your program should *not* call block_paint.new_grid in this case, but it did.")

    def testBadLetter1(self):
        '''
        Run blockpaint with bad/unsupported letter (lowercase)
        '''
        program_inputs = ['5', 'r']
        self.badInputExample(FILENAME, program_inputs, "A valid scale (5) but invalid letter ('r') was given as input.  Your program should *not* call block_paint.new_grid in this case, but it did.")

    def testBadLetter2(self):
        '''
        Run blockpaint with bad/unsupported letter (lowercase)
        '''
        program_inputs = ['5', 'R']
        self.badInputExample(FILENAME, program_inputs, "A valid scale (5) but invalid letter ('R') was given as input.  Your program should *not* call block_paint.new_grid in this case, but it did.")

    def testLettern9(self):
        '''
        Test drawing an N with scale 5
        '''
        program_inputs = ['9', 'n']
        expected = [
            ['x',' ',' ',' ',' ',' ',' ',' ','x'],
            ['x','x',' ',' ',' ',' ',' ',' ','x'],
            ['x',' ','x',' ',' ',' ',' ',' ','x'],
            ['x',' ',' ','x',' ',' ',' ',' ','x'],
            ['x',' ',' ',' ','x',' ',' ',' ','x'],
            ['x',' ',' ',' ',' ','x',' ',' ','x'],
            ['x',' ',' ',' ',' ',' ','x',' ','x'],
            ['x',' ',' ',' ',' ',' ',' ','x','x'],
            ['x',' ',' ',' ',' ',' ',' ',' ','x']
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)

    def testLetterE5(self):
        '''
        Test drawing an E with scale 5
        '''
        program_inputs = ['5', 'E']
        expected = [
            ['x','x','x',' ',' '],
            ['x',' ',' ',' ',' '],
            ['x','x','x',' ',' '],
            ['x',' ',' ',' ',' '],
            ['x','x','x',' ',' '],
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)
    
    def testLettere5(self):
        '''
        Test drawing an e with scale 5
        '''
        program_inputs = ['5', 'e']
        expected = [
            ['x','x','x',' ',' '],
            ['x',' ',' ',' ',' '],
            ['x','x','x',' ',' '],
            ['x',' ',' ',' ',' '],
            ['x','x','x',' ',' '],
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)

    def testLetterE9(self):
        '''
        Test drawing an E with scale 5
        '''
        program_inputs = ['9', 'E']
        expected = [
            ['x','x','x','x','x','x',' ',' ',' '],
            ['x',' ',' ',' ',' ',' ',' ',' ',' '],
            ['x',' ',' ',' ',' ',' ',' ',' ',' '],
            ['x',' ',' ',' ',' ',' ',' ',' ',' '],
            ['x','x','x','x','x','x',' ',' ',' '],
            ['x',' ',' ',' ',' ',' ',' ',' ',' '],
            ['x',' ',' ',' ',' ',' ',' ',' ',' '],
            ['x',' ',' ',' ',' ',' ',' ',' ',' '],
            ['x','x','x','x','x','x',' ',' ',' '],
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)

    def testLetterY5(self):
        '''
        Test drawing an Y with scale 5
        '''
        program_inputs = ['5', 'Y']
        expected = [
            ['x',' ',' ',' ','x'],
            [' ','x',' ','x',' '],
            [' ',' ','x',' ',' '],
            [' ',' ','x',' ',' '],
            [' ',' ','x',' ',' ']
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)

    def testLettery9(self):
        '''
        Test drawing an y with scale 9
        '''
        program_inputs = ['9', 'y']
        expected = [
            ['x',' ',' ',' ',' ',' ',' ',' ','x'],
            [' ','x',' ',' ',' ',' ',' ','x',' '],
            [' ',' ','x',' ',' ',' ','x',' ',' '],
            [' ',' ',' ','x',' ','x',' ',' ',' '],
            [' ',' ',' ',' ','x',' ',' ',' ',' '],
            [' ',' ',' ',' ','x',' ',' ',' ',' '],
            [' ',' ',' ',' ','x',' ',' ',' ',' '],
            [' ',' ',' ',' ','x',' ',' ',' ',' '],
            [' ',' ',' ',' ','x',' ',' ',' ',' '],
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)

    def testLetterz5(self):
        '''
        Test drawing an z with scale 5
        '''
        program_inputs = ['5', 'z']
        expected = [
            ['x','x','x','x','x'],
            [' ',' ',' ','x',' '],
            [' ',' ','x',' ',' '],
            [' ','x',' ',' ',' '],
            ['x','x','x','x','x']
        ]
        self.expectSuccess(FILENAME, program_inputs, expected)



if __name__ == '__main__':
    FILENAME = 'hw4_letters.py'
    if len(sys.argv) > 1:
        FILENAME = sys.argv.pop(1)
    unittest.main(verbosity=3)

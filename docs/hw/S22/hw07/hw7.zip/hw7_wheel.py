# ----------------------------------------------------------
# --------          HW 7: wheel of fortune         ---------
# ----------------------------------------------------------

# ----------------------------------------------------------
# Please answer these questions after you have completed this
# program
# ----------------------------------------------------------
# Name:
# Time spent on this problem:
#
# Collaborators and sources:
#   (List any collaborators or sources here.)
#
# ----------------------------------------------------------

# Complete the code below for wheel of fortune

# you can just _use_ these functions in your code; you should not
# make any changes to them
def scoreboard(num_missed):
    ''' (int) -> 
    Print the scoreboard for the game
    '''
    print("---------------")
    scoreStr = "|"
    for i in range(1,8):
        if i <= num_missed:
            scoreStr += "X|"
        else:
            scoreStr += " |"
    print(scoreStr)
    print("---------------")


def hide_consonants(cdn):
    """
    >>> hide_consonants('abcde')
    'a___e'
    """
    output = ''
    for i in cdn:
        if is_vowel(i):
            output += i
        else:
            output += '_'
    return output


def shuffle_word(cdn, seed=None):
    """
    shuffle a word and show the vowels
    >>> shuffle_word('abcde', seed=0)
    'cbaed'
    """
    import random
    if seed is not None:
        random.seed(seed)
    l = [x for x in cdn]
    random.shuffle(l)
    return ''.join(l)


def is_vowel(a):
    """
    >>> is_vowel('c')
    False
    >>> is_vowel('a')
    True
    """
    return a.lower() in 'aeiou'    


# your code should go between here and main


def is_valid_guess(a):
    """
    >>> is_valid_guess('A')
    False
    >>> is_valid_guess('B')
    True
    >>> is_valid_guess('123')
    False
    >>> is_valid_guess('BX')
    False
    """


def one_game(word, secret):
    '''str -> None
       Play one game of wheel of fortune.'''
    state = hide_consonants(secret)
    # your code for this function should start here


########Main############


def main():
    import random
    words = ['SPRING', 'LEAVES', 'WARM', 'MUD', 'SUNNY', 'WINDY', 'RAINY']
    word = random.choice(words)    
    secret = shuffle_word(word)
    print("for testing, the secret word is: ", word)
    one_game(word, secret)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    main()
